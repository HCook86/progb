from .main import Bar

__version__ = "0.0.7"
__author__ = {"Henry Cook":"henryscookolaizola@gmail.com"}